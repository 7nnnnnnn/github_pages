<template>
  <div class="">changePassword页面</div>
</template>

<script>
import { defineComponent } from "vue"
export default defineComponent({

});
</script>

<style lang="scss" scoped></style>
