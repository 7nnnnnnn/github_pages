export const isEven=n=>n%2===0
const isEven1=function(n){
    return n%2===0
}