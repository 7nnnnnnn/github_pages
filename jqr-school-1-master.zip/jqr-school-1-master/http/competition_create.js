//统一api管理
import instance from "./axios";
const userLogin = (data) => {
    //返回Promise对象
    return instance.request({
        url: 'api/mobile/elogin', //url=baseUrl+url,
        method: 'post',
        data,
        headers: {

        }
    })
}

//对应all
const getallcompetition_create = (data) => {
    return instance.request({
        url: 'api/competition_create/all',
        data
    })
}
//对应delete
const deletecompetition_create = (params) => {
    return instance.request({
        url: '/api/competitionCreate/delete',
        params
    })
}
//对应add
const addcompetition_create = (data) => {
    return instance.request({
        url: '/api/competitionCreate/add',//看api文档
        method: 'post',
        data
    })
}
//对应edit
const editcompetition_create = (data) => {
    return instance.request({
        url: '/api/competitionCreate/edit',//改 
        method: 'post',
        data
    })
}
//可有可无,没用到
const getonecompetition_create = (data) => {
    return instance.request({
        url: 'api/competition_create/one',//改

        data
    })
}

export {
    userLogin,
    getallcompetition_create,
    addcompetition_create,
    deletecompetition_create,
    editcompetition_create,
    getonecompetition_create

} 