<template>
    <!-- // components 文件夹 一般组件 -->
    <!-- // views文件夹 页面组件 -->
    <div class="">组件</div>
</template>

<script>
import { defineComponent } from "vue"
export default defineComponent({

});
</script>

<style lang="scss" scoped></style>
